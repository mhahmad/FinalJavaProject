package lab12_skeleton;

import lab12_skeleton.Album;
import lab12_skeleton.Song;

public class Main {

	public static void main(String[] args) {
		Album ten  = new Album("Pearl Jam");
		ten.addSong(new Song("Once"));
		ten.addSong(new Song("Even Flow"));
		ten.addSong(new Song("Alive"));
		ten.addSong(new Song("Black"));
		ten.addSong(new Song("Jeremy"));
		ten.serialize();
		ten.printSongList();
		ten.removeSong(ten.getSong("Once"));
		ten.printSongList();
		ten.deserialize();
		ten.printSongList();

	}

}
