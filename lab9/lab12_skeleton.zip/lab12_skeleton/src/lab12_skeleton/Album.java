package lab12_skeleton;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Album {
	
	private String name;
	private SongList songList;
	
	public Album(String name) {
		super();
		this.name = name;
		this.songList = new SongList();
	}
	
	public boolean addSong(Song song) {
		return songList.addSong(song);
	}
	
	public boolean removeSong(Song song) {
		return songList.removeSong(song);
	}
	
	public void songInfo(Song song) {
		songList.songInfo(song);
	}
	
	public SongList getSongList() {
		return songList;
	}
	
	public void printSongList() {
		System.out.println("Song list:");
		for(Song s : songList.getSongs())
			System.out.println("- " + s.getTitle());
	}
	
	public Song getSong(String title) {
		return songList.getSong(title);
	}

}
